package com.example.myapplication;

import java.io.Serializable;

public class ImagesResponse implements Serializable {
    private int id;
    private String url ;
    private String name ;
    private  String description ;
    private String terms ;
    private String current_value;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTerms() {
        return terms;
    }

    public void setTerms(String terms) {
        this.terms = terms;
    }

    public String getcurrent_value() {return current_value; }

    public void setCurrent_value(String current_value) {
        this.current_value = current_value;
    }
}
