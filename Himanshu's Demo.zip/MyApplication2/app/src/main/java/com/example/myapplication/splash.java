package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Timer;
import java.util.TimerTask;

public class splash extends AppCompatActivity {
    //Variables
    Timer timer = new Timer();
    Animation topAnim , bottomAnim;
    ImageView image;
    TextView logo, slogan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash);

    //Animations
    topAnim = AnimationUtils.loadAnimation(this,R.anim.top_animation);
    bottomAnim = AnimationUtils.loadAnimation(this,R.anim.bottom_animation);

    //Hooks
    image = findViewById(R.id.imageView2);
    logo = findViewById(R.id.textView2);
    slogan = findViewById(R.id.textView3);

        image.setAnimation(topAnim);
        logo.setAnimation(bottomAnim);
        slogan.setAnimation(bottomAnim);
//timer-delay
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                Intent intent = new Intent(splash.this,MainActivity.class);
                startActivity(intent);
                finish();
            }
        }, 4000 );


    }}
