package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.net.URL;

import retrofit2.http.GET;

public class ClickedActivity extends AppCompatActivity {
ImagesResponse imagesResponse;
TextView Name;
ImageView imageView;
TextView term;
TextView disc;
TextView value;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clicked);
        Name = findViewById(R.id.selectedName);
        imageView = findViewById(R.id.selectedImage);
        term = findViewById(R.id.selectedTerm);
       disc = findViewById(R.id.selecteddisc);
       value = findViewById(R.id.selectedvalue);


        Intent intent = getIntent();
        if (intent.getExtras() != null){
            imagesResponse = (ImagesResponse)intent.getSerializableExtra("data");
         Name.setText(imagesResponse.getName());
         disc.setText(imagesResponse.getDescription());
            term.setText(imagesResponse.getTerms());
         value.setText(imagesResponse.getcurrent_value());
            GlideApp.with(this).load(imagesResponse.getUrl()).into(imageView);

        }

    }
}
