package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    private List<ImagesResponse> ImagesResponseList = new ArrayList<>();
    GridView gridView;
    private ProgressDialog progressDialog;
    private boolean isLoading;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        this.isLoading = true;

        progressDialog = new ProgressDialog(this);
        progressDialog.setTitle("Please wait");
        gridView = findViewById(R.id.gridview);
        getAllImages();
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent myintent = new Intent(view.getContext(), ClickedActivity.class);
                view.getContext().startActivity(myintent.putExtra("data", ImagesResponseList.get(i)));

            }
        });
    }


    public void getAllImages() {
        progressDialog.show();


        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(5000);
                } catch (Exception e) {

                } finally {
                    if (isLoading) {
                        new Handler(Looper.getMainLooper()).post(new Runnable() {
                            public void run() {
                                if (isLoading) {
                                    Toast.makeText(MainActivity.this, "Please check your internet connection or hold a moment while we try to reconnect.", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
            }
        }).start();


        Call<List<ImagesResponse>> imagesResponse = ApiClient.getInterface().getAllImages();
        imagesResponse.enqueue(new Callback<List<ImagesResponse>>() {

            @Override
            public void onResponse(Call<List<ImagesResponse>> call, Response<List<ImagesResponse>> response) {
                if (response.isSuccessful()) {
                    isLoading = false;

                    String message = "Welcome in Grocery store";
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();

                    ImagesResponseList = response.body();

                    CustomAdapter customAdapter = new CustomAdapter(ImagesResponseList, MainActivity.this);
                    gridView.setAdapter(customAdapter);
                    progressDialog.hide();

                } else {
                    String message = "error";
                    Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<ImagesResponse>> call, Throwable t) {
                String message = t.getLocalizedMessage();
                Toast.makeText(MainActivity.this, "Check your internet connection  ", Toast.LENGTH_LONG).show();

            }
        });
    }


    public class CustomAdapter extends BaseAdapter {
        private List<ImagesResponse> ImagesResponseList;
        private Context context;
        private LayoutInflater layoutInflater;

        public CustomAdapter(List<ImagesResponse> imagesResponseList, Context context) {
            ImagesResponseList = imagesResponseList;
            this.context = context;
            this.layoutInflater = (LayoutInflater) context.getSystemService(LAYOUT_INFLATER_SERVICE);

        }


        @Override
        public int getCount() {
            return ImagesResponseList.size();

        }

        @Override
        public Object getItem(int i) {
            return null;
        }

        @Override
        public long getItemId(int i) {
            return 0;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {
            if (view == null) {
                view = layoutInflater.inflate(R.layout.row_grid_items, viewGroup, false);
            }
            ImageView imageView = view.findViewById(R.id.imageView);
            TextView textView = view.findViewById(R.id.textView);
            TextView offer = view.findViewById(R.id.offer);
            offer.setText(ImagesResponseList.get(i).getcurrent_value());
            textView.setText(ImagesResponseList.get(i).getName());
            GlideApp.with(context)
                    .load(ImagesResponseList.get(i).getUrl())
                    .into(imageView);
            return view;
        }
    }


}